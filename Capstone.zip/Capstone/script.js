// Predefined access key
const predefinedKey = "password"; // Replace with your actual predefined key
//define user and password
document
  .getElementById("loginForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    validate();
  });
document
  .getElementById("updateForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    update();
  });
function validate() {
  const username = document.getElementById("ID").value;
  const password = document.getElementById("password").value;
  const accessKey = document.getElementById("key").value;

  // Check if the provided access key matches the predefined key
  if (accessKey === predefinedKey) {
    // If success, open test.html
    window.location.href = "test.html";
  } else {
    // If failed, display an error message
    document.getElementById("errorMessage").innerText =
      "Access key is incorrect. Please try again.";
  }
}

function update() {
  const aboutus = document.getElementById("").value;
  const menuitems = document.getElementById("menu").value;
  const message = document.getElementById("message").value;
}
